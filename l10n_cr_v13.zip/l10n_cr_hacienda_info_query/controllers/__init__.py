 #import estadisticas #Odoo 8 hacia atras
from . import routes_controller