# -*- coding: utf-8 -*-

from . import electronic_invoice

