from odoo import api, SUPERUSER_ID


# change state xml_id to fix errors
def pre_init_hook(cr):
    return
    cr.execute("UPDATE public.ir_model_data "
               "SET module = 'l10n_cr_country_codes', name = 'state_sj' "
               "WHERE module = 'l10n_cr' and name = 'state_SJ';")

    cr.execute("UPDATE public.ir_model_data "
               "SET module = 'l10n_cr_country_codes', name = 'state_a' "
               "WHERE module = 'l10n_cr' AND name = 'state_A';")

    cr.execute("UPDATE public.ir_model_data "
               "SET module = 'l10n_cr_country_codes', name = 'state_h' "
               "WHERE module = 'l10n_cr' AND name = 'state_H';")

    cr.execute("UPDATE public.ir_model_data "
               "SET module = 'l10n_cr_country_codes', name = 'state_c' "
               "WHERE module = 'l10n_cr' AND name = 'state_C';")

    cr.execute("UPDATE public.ir_model_data "
               "SET module = 'l10n_cr_country_codes', name = 'state_p' "
               "WHERE module = 'l10n_cr' AND name = 'state_P';")

    cr.execute("UPDATE public.ir_model_data "
               "SET module = 'l10n_cr_country_codes', name = 'state_g' "
               "WHERE module = 'l10n_cr' AND name = 'state_G';")

    cr.execute("UPDATE public.ir_model_data "
               "SET module = 'l10n_cr_country_codes', name = 'state_l' "
               "WHERE module = 'l10n_cr' AND name = 'state_L';")
