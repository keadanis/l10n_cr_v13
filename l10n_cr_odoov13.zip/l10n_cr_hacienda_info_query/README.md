Este modulo funciona para Consultar las cedulas del API de Hacienda en odoo al solo digitar la cedula el request inserta cedula nombre y tipo cedula en el back office y esperamos pronto en el olvidado POS
<br>
12.0 para Odoo 12
<br>
Por Odoo CR, Factura Sempai y FSS Solutions
<br>
Instalacion
<br>
Instalar el modulo l10n_cr_hacienda_info_query de forma Habitual.
