# -*- coding: utf-8 -*-

from . import country_codes
from . import res_company
from . import res_partner

